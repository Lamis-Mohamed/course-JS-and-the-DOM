Weather-Journal App Project



Description:

An iteractive API that is used to input your "City,Country" Names in the Zip Code box 
and enter what do you feel in its corresponding field box  then Click the Generate button
, and the API will generate your today date,location temperature , and your weather feelings 
then will return these data in the "Most Recent" box at the lower part of the page.


Structure:

this API has been built using the server side code in "server.js" , at which we can use the Express 
node package to run server and routes and to use the Express useful methods dedicated for this.
and we used also the client side code "app.js" ,at which we can setup and execute the routes  
the post and get routes to make the  webpage or the webApi interactive by using the ASYNC function, 
Fetch API and the chain promises (.then) to build it easy way.


Input Example :

ZIP CODE : Cairo,EG (or) London,uk
what do you feel? : Cold (or) hot


Zip Validation test cases:

1-if the error message was "city not found", the console will send you a message "enter valid zip"
2-if you enter city name starting with small letter, console log will send you a message "enter first capital letter"

