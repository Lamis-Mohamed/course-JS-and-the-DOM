/* Global Variables */

// Create a new date instance dynamically with JS
let d = new Date();
let newDate = d.getMonth()+1+'.'+ d.getDate()+'.'+ d.getFullYear();
let baseURL = 'http://api.openweathermap.org/data/2.5/weather?q='
const apiKey = '&APPID=0f0ba16a1b52ab287b7b3f4600a8fe32&units=metric';

document.getElementById('generate').addEventListener('click', performAction);

//Defining the 	functions

//Click Action Chain promises Function to post data to the UI
const zipvalid = async(zipcode)=>{

  if (zipcode[0] != zipcode[0].toUpperCase()){console.log("enter first Capital letter")}
}


function performAction(e){
const zipcode =  document.getElementById('zip').value;
let User1 = document.getElementById('feelings').value;


//capitalize validation
zipvalid(zipcode);
//Promises Chain

//get the data from weather app
getWeather(baseURL,zipcode,apiKey)
//take the API return data and input it to the Post Route
.then(function(data){
 if (data.message ==  "city not found")
    {console.log("enter valid zipcode")}
    // Add data
     console.log(data);
    //select the required data to post it using POST route
    postData('/weather', {temperature:data.main.temp, date: newDate, userResponse:User1} );
  })
  //Update UI
  .then(function(){updateUI()})
}



//Weather API GET Async Function
const getWeather = async (baseURL, zipc, key)=>{
//Fetch API used for preparing for Promises Chain
  
  //const res = await axios.get(baseURL+zipc+key)  /* trying axios instead of fetch but it doesn't work*/
   const res = await fetch(baseURL+zipc+key)
  try {

    const data = await res.json();
    console.log(data)
    return data;
  }  catch(error) {
    console.log("error",error)
    // appropriately handle the error
    
  };
};

// Async POST
const postData = async ( url = '', data = {})=>{
  console.log(data)
    const response = await fetch(url, {
    method: 'POST', // *GET, POST, PUT, DELETE, etc.
    credentials: 'same-origin', // include, *same-origin, omit
    headers: {
        'Content-Type': 'application/json',
    },
    body: JSON.stringify(data), // body data type must match "Content-Type" header        
  });

    try {
      const newData = await response.json();
      // console.log(newData);
      return newData
    }catch(error) {
    console.log("error", error);
    // appropriately handle the error
    }
}

//UpdateUI GET Async function
const updateUI = async () => {
  //Fetch API used for preparing for Promises Chain
  const request = await fetch('/all');
  try{
    const allData = await request.json();
    let i = allData.length;
    let d1 = allData[i];

    console.log(i);
     console.log(allData);
    document.getElementById('date').innerHTML = allData[i-1].date;
    document.getElementById('temp').innerHTML = allData[i-1].temperature;
    document.getElementById('content').innerHTML = allData[i-1].userResponse;

  }catch(error){
    console.log("error", error);
  }
}

